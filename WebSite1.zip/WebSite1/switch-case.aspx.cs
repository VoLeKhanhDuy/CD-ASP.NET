﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class switch_case : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_kq_Click(object sender, EventArgs e)
    {
        int a = Int32.Parse(txt_a.Text);
        int b = Int32.Parse(txt_b.Text);
        string phepToan = rdbl.SelectedValue;
        switch (phepToan)
        {
            case "+":
                lb_kq.Text = (a + b).ToString();
                break;
            case "-":
                lb_kq.Text = (a - b).ToString();
                break;
            case "*":
                lb_kq.Text = (a * b).ToString();
                break;
            case "/":
                float kq = (float)a/b;
                lb_kq.Text = kq.ToString();
                break;
            default:
                lb_kq.Text = "Sai cú pháp!!";
                break;
        }
    }
}