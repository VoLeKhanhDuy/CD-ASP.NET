﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class loop : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_kq_Click(object sender, EventArgs e)
    {
        int n = Int32.Parse(txt_a.Text);
        int tongChan = 0;
        for(int i = 0; i < n; i++)
        {
            if(i % 2 == 0)
            {
                tongChan += i;
            }
        }
        lb_kq.Text = tongChan.ToString();
    }
   
}