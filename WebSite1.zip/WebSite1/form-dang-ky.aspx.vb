﻿
Partial Class form_dang_ky
    Inherits System.Web.UI.Page

End Class
