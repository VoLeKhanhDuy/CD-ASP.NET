﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void btn_kq_Click(object sender, EventArgs e)
    {
        int a = Int32.Parse(txt_a.Text);
        int b = Int32.Parse(txt_b.Text);
        lb_kq.Text = (a + b).ToString();
    }
}